package com.devmedia.model;

public class UsuarioDAO
{
	public boolean inserir(Usuario usuario)
	{
		//t.beginTransaction();
		//session.save(usuario);
		//t.commit();
		return true;
	}
}